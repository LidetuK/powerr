"use client"

import type React from "react"
import Link from "next/link"

interface GlowingButtonProps {
  href: string
  children: React.ReactNode
  className?: string
}

export default function GlowingButton({ href, children, className = "" }: GlowingButtonProps) {
  return (
    <Link
      href={href}
      className={`
        relative inline-flex items-center justify-center px-8 py-4 
        overflow-hidden font-medium text-white bg-purple-600 rounded-lg 
        group hover:bg-purple-700 transition-all duration-300 
        shadow-[0_0_15px_rgba(124,58,237,0.5)] hover:shadow-[0_0_25px_rgba(124,58,237,0.7)]
        ${className}
      `}
    >
      <span className="relative">{children}</span>
    </Link>
  )
}
