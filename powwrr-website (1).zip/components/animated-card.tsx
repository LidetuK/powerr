"use client"

import type React from "react"
import { useState } from "react"

interface AnimatedCardProps {
  children: React.ReactNode
  className?: string
}

export default function AnimatedCard({ children, className = "" }: AnimatedCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className={`
        bg-white rounded-lg shadow-lg overflow-hidden
        transition-all duration-300 ease-in-out
        ${isHovered ? "transform -translate-y-2 shadow-xl" : ""}
        ${className}
      `}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {children}
    </div>
  )
}
